Before you will be able to compile and run this sample, you might correct path to reference to COM component Microsoft HTML Object Library 4.0, 
located at C:\WINDOWS\assembly\GAC\Microsoft.mshtml\7.0.3300.0__b03f5f7f11d50a3a\Microsoft.mshtml.dll.

Another thing you might correct is path to reference to .Net component, System.Configuration.

If you have installed VS 2005 with default options, program should work without this modifications.

After this, build and run project. 

Have fun!!!